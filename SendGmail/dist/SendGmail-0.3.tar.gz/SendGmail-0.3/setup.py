from setuptools import setup

setup(name='SendGmail',
        version='0.3',
        description='Send email using gmail',
        url='#',
        author='eazariDev',
        author_email='eazari.dev@gmail.com',
        license='MIT',
        packages=['SendGmail'],
        zip_safe=False)
