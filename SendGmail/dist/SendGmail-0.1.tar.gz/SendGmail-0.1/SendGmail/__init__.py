from SendGmail.handler import send_mail

__all__ = ['send_mail']

