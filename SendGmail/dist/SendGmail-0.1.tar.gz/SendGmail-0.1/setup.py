from setuptools import setup

setup(name='SendGmail',
        version='0.1',
        description='Send email using gmail',
        url='#',
        author='eazariDev',
        author_email='eazari.dev@gmail.com',
        license='MIT',
        packages=['SendGmail'],
        install_requires=['smtplib', 'email'],
        zip_safe=False)
